import typing

from . import base
from . import fields
from . import mixins
from .user import User


class VoiceChatParticipantsInvited(base.TelegramObject, mixins.Downloadable):
    """
    This object represents a service message about new members invited to a voice chat.

    https://core.telegram.org/bots/api#voicechatparticipantsinvited
    """

    users: typing.List[User] = fields.ListField(base=User)
